package com.bitwise.service;

import java.util.ArrayList;

public interface IProductService {

	double productprice(ArrayList<String> al);
	
}
